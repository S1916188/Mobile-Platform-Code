// Philippe Cranskens - student number - s1916118
package org.me.gcu.equakestartercode;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;

import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.ListView;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity
{
    //Declare controls and variables
    ListView lv;
    private String urlSource="http://quakes.bgs.ac.uk/feeds/MhSeismology.xml";
    private ArrayList<Earthquake> earthquakesList, earthquakesSearch;
    private ArrayList<String> locationAndMagnitude;
    private Button btnHighest, btnLowest, btnClearFilters, btnSearchDate;
    private Boolean highestClicked = false;
    private Boolean lowestClicked = false;
    private CheckBox checkSearchDate;
    private DatePicker datePickerStart, datePickerEnd;
    private TableRow dateRow, searchRow, northEastRow, southWestRow, largestRow, deepShallowRow;
    private TextView txtSearchInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        requestWindowFeature(Window.FEATURE_NO_TITLE); // hide the title(app name)
        getSupportActionBar().hide(); // Hide the title bar
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN); //enable full screen
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Initialise variables for use further down
        //ArrayList for all earthquakes parsed from the stream
        earthquakesList = new ArrayList<Earthquake>();
        //array list for searched earthquakes
        earthquakesSearch = new ArrayList<Earthquake>();
        locationAndMagnitude = new ArrayList<String>();

        //call method to find all controls as there is quite a lot and this makes it look neater.
        findControls();

        //Hides search button whilst the user is not searching for a specific date
        txtSearchInfo.setVisibility(View.GONE);
        datePickerStart.setVisibility(View.GONE);
        datePickerEnd.setVisibility(View.GONE);
        btnSearchDate.setVisibility(View.GONE);

        //On click listener for filtering list by highest magnitude
        btnHighest.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                //If button is clicked, lowestClicked variable is set to false, while highestClicked is set to true
                lowestClicked = false;
                highestClicked = true;
                //Location and magnitude array is reset so a new array worth of data is not added every time a button is clicked
                locationAndMagnitude = new ArrayList<String>();
                //runs the async task ProcessInBackground that populates the listview
                new ProcessInBackground().execute();
            }
        });

        //onclick listener for filtering by lowest magnitude first
        btnLowest.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                //Same as previous button but variables reversed
                highestClicked = false;
                lowestClicked = true;
                //Location and magnitude array is reset so a new array worth of data is not added every time a button is clicked
                locationAndMagnitude = new ArrayList<String>();
                //runs the async task ProcessInBackground that populates the listview
                new ProcessInBackground().execute();
            }
        });

        btnClearFilters.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                //sets variables to false and populates listview as normal
                highestClicked = false;
                lowestClicked = false;
                locationAndMagnitude = new ArrayList<String>();
                earthquakesList = new ArrayList<Earthquake>();
                new ProcessInBackground().execute();
            }
        });

        //Checkbox button on click listener that hides the listview control so user can search
        checkSearchDate.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {

                Calendar today = Calendar.getInstance();
                Calendar fiftyDaysAgo = (Calendar) today.clone();
                //sets variable to 50 day's before current day.
                fiftyDaysAgo.add(Calendar.DATE, -50);
                //Set date picker cut off point as current day, meaning the user cannot select in the future.
                datePickerStart.setMaxDate(today.getTimeInMillis());
                //As the data pulled from the website only goes back 50 days, ensure that the calender tool can only select 50 days in the past
                datePickerStart.setMinDate(fiftyDaysAgo.getTimeInMillis());

                //Set date picker cut off point as current day, meaning the user cannot select in the future
                datePickerEnd.setMaxDate(today.getTimeInMillis());
                //As the data pulled from the website only goes back 50 days, ensure that the calender tool can only select 50 days in the past
                datePickerEnd.setMinDate(fiftyDaysAgo.getTimeInMillis());

                //Hide listview as the user is using the search date function
                lv.setVisibility(View.GONE);
                datePickerStart.setVisibility(View.VISIBLE);
                datePickerEnd.setVisibility(View.VISIBLE);
                btnSearchDate.setVisibility(View.VISIBLE);
                //Enables the search date text info TextView
                txtSearchInfo.setVisibility(view.VISIBLE);

                //When the checkbox is clicked, check to see if it is checked or unchecked.
                if(!checkSearchDate.isChecked())
                {
                    //if it is unchecked, ensure the listview is visible again and the text search info is invisible.
                    lv.setVisibility(View.VISIBLE);
                    txtSearchInfo.setVisibility(view.GONE);
                    datePickerStart.setVisibility(View.GONE);
                    datePickerEnd.setVisibility(View.GONE);
                    btnSearchDate.setVisibility(View.GONE);
                }
            }
        });

        //OnClickListener for search button
        btnSearchDate.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                //SimpleDateFormat for changing date format to acceptable standard.
                SimpleDateFormat sdf = new SimpleDateFormat("EEE, d MMM yyyy HH:mm:ss");
                //Get dates of two datepickers
                Date firstDate = getDateFromDatePicker(datePickerStart);
                //set's time to the very start of the day to ensure a single date can be selected.
                firstDate.setHours(0);
                firstDate.setMinutes(0);
                firstDate.setSeconds(1);

                Date secondDate = getDateFromDatePicker(datePickerEnd);
                //sets the time to the very end of the day so a single date can be selected.
                secondDate.setHours(23);
                secondDate.setMinutes(59);
                secondDate.setSeconds(59);

                //Checks to see if the second datepicker is before the first.
                if (secondDate.before(firstDate))
                {
                    //if the second date picker is before the first, reverse the values, ensuring there is still results to be had.
                    firstDate = getDateFromDatePicker(datePickerEnd);
                    secondDate = getDateFromDatePicker(datePickerStart);
                }

                //Clears the earthquake search history to ensure data is not being replicated
                earthquakesSearch.clear();

                //compare the two dates and return the most northern, southern, western and eastern earthquake

                //Loop round every earthquake listed
                for(int i = 0; i < earthquakesList.size(); i++)
                {
                    //get time and date of every earthquake in list
                    String earthquakeTimeAndDate = earthquakesList.get(i).getTime();
                    Date d = null;
                    //try catch to handle parse exception
                    try
                    {
                        //Parse the string date retrieved into a Date object
                        d = sdf.parse(earthquakeTimeAndDate);
                    }
                    catch (ParseException e)
                    {
                        e.printStackTrace();
                    }
                    //Make sure the date retrieved from the earthquake is within the two date picker dates.
                    if((d.equals(firstDate) || d.after(firstDate)) && (d.before(secondDate) || d.equals(secondDate)))
                    {
                        //If the earthquake date is within the two date picker values, add it to an array list specifically for earthquakes within the search parameters
                        earthquakesSearch.add(earthquakesList.get(i));
                    }
                }

                //if no earthquakes are within the search parameters then return with an error message informing the user
                if (earthquakesSearch.isEmpty())
                {
                    showToast("No earthquakes in this range, please try a different date");
                    return;
                }

                //If there are results, start new activity to view earthquakes within the parameters.
                Intent intent = new Intent(view.getContext(), SearchInfo.class);
                //Puts the earthquake list in the intent for passing to the new activity
                intent.putExtra("earthquakeList", earthquakesSearch);
                //starts the new activity
                startActivity(intent);
            }
        });


        //Sets onclick listener for the listview
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                Intent intent = new Intent(view.getContext(), EarthquakeInfo.class);
                //gets the earthquake at the position clicked
                Earthquake passedEarthquake = earthquakesList.get(position);
                //puts the earthquake in the intent
                intent.putExtra("earthquake", passedEarthquake);
                //starts activity with intent.
                startActivity(intent);
            }
        });

        //Creates new handler instance
        Handler handler = new Handler();
        //Defines the code block to be executed
         Runnable runnableCode = new Runnable()
         {
            @Override
            public void run()
            {
                //Runs the async task
                new ProcessInBackground().execute();
                //ensures variables for filtering are set to false.
                lowestClicked=false;
                highestClicked=false;
                //declares array lists as new to avoid duplication
                locationAndMagnitude = new ArrayList<String>();
                earthquakesList = new ArrayList<Earthquake>();
                //Runs the async task code that populates the list with earthquakes every 10 minutes
                handler.postDelayed(this, 600000);
            }
        };
        // Start the initial runnable task by posting through the handler
        handler.post(runnableCode);

    }

    //Acquires the date from the entered datePicker
    private Date getDateFromDatePicker(DatePicker datePicker)
    {
        //Get's the day, month and year from the datepicker and assigns them to variables.
        int day = datePicker.getDayOfMonth();
        int month = datePicker.getMonth();
        int year =  datePicker.getYear();

        //new instance of Calender
        Calendar calendar = Calendar.getInstance();
        //Sets the values for day, month and year.
        calendar.set(year, month, day);

        //returns the calender date object.
        return calendar.getTime();
    }

    //method to clear up the oncreate method by finding controls here
    private void findControls()
    {
        lv = (ListView) findViewById(R.id.listView);
        btnHighest = (Button) findViewById(R.id.btnSortHigh);
        btnLowest = (Button) findViewById(R.id.btnSortLow);
        btnClearFilters = (Button) findViewById(R.id.btnClear);
        checkSearchDate = (CheckBox) findViewById(R.id.checkSearch);
        datePickerStart = (DatePicker) findViewById(R.id.datePicker1);
        datePickerEnd = (DatePicker) findViewById(R.id.datePicker2);
        btnSearchDate = (Button) findViewById(R.id.btnSearch);

        txtSearchInfo = (TextView) findViewById(R.id.txtSelectDates);
        dateRow = (TableRow) findViewById(R.id.rowDatePicker);
        searchRow = (TableRow) findViewById(R.id.rowSearchBtn);

    }

    //method to open connection to the websites URL
    public InputStream getInputStream(URL url)
    {
        try
        {
            return url.openConnection().getInputStream();
        }
            catch (IOException e)
            {
                return null;
            }
        }

        //Async task that runs as soon as the application opens
        public class ProcessInBackground extends AsyncTask<Integer, Void, Exception>
        {
            ProgressDialog progressDialog = new ProgressDialog(MainActivity.this);
            Exception exception = null;

            //Runs before the main thread
            @Override
            protected void onPreExecute()
            {
                super.onPreExecute();

                //If the app takes longer than usual to load, the user will see this, informing them the app is working.
                progressDialog.setMessage("Loading Feed.... Please Wait....");
                progressDialog.show();
            }


            //Main task that runs after the pre execute method.
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            protected Exception doInBackground(Integer... integers)
            {
                //Checks to see if the button to filter by highest magnitude is clicked
                if(highestClicked == true)
                {
                    //Collections.sort allows a list to be sorted by a specific value.
                    Collections.sort(earthquakesList, new Comparator<Earthquake>()
                    {
                        @Override
                        public int compare(Earthquake earthquake, Earthquake t1)
                        {
                            //in this case the list is sorted by earthquake magnitude
                            return t1.getMagnitude().compareToIgnoreCase(earthquake.getMagnitude());
                        }
                    });

                    //With the list sorted by magnitude, a simple foreach loop allows the locationAndMagnitude arraylist to be populated by a list of earthquakes in order of magnitude.
                    for (int i = 0; i < earthquakesList.size(); i++)
                    {
                        String[] descriptionArr = earthquakesList.get(i).getDescription();
                        String locationAndMagHigh = descriptionArr[1] + " - " + descriptionArr[4];
                        locationAndMagnitude.add(locationAndMagHigh);
                    }
                }

                //The else if statement, simply does the opposite and sorts the earthquakes by lowest magnitude and populates the same array
                //list with earthquakes sorted by lowest magnitude instead of highest
                else if(lowestClicked == true)
                {
                    Collections.sort(earthquakesList, new Comparator<Earthquake>()
                    {
                        @Override
                        public int compare(Earthquake earthquake, Earthquake t1)
                        {
                            return earthquake.getMagnitude().compareToIgnoreCase(t1.getMagnitude());
                        }
                    });


                    for (int i = 0; i < earthquakesList.size(); i++)
                    {
                        String[] descriptionArr = earthquakesList.get(i).getDescription();
                        String locationAndMagLow = descriptionArr[1] + " - " + descriptionArr[4];
                        locationAndMagnitude.add(locationAndMagLow);
                    }
                }

                //If neither buttons are clicked, the list is populated with the latest earthquakes first.
                else if(highestClicked == false && lowestClicked == false)
                    {
                        //Creates new earthquake object to be used
                    Earthquake earthquake = new Earthquake();
                    try {
                        //sets the URL to be used
                        URL url = new URL("http://quakes.bgs.ac.uk/feeds/MhSeismology.xml");

                        //Creates a new pull parsor factory instance
                        XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
                        factory.setNamespaceAware(false);
                        //creates new parser object.
                        XmlPullParser xpp = factory.newPullParser();
                        xpp.setInput(getInputStream(url), "UTF_8");

                        //A boolean variable to determine if the parser is inside the correct item as there are two of the same,
                        //and one of them is not an earthquake item
                        boolean insideItem = false;
                        int eventType = xpp.getEventType();

                        //Start of the while loop that ensures parser is not at the end of the document
                        while (eventType != XmlPullParser.END_DOCUMENT)
                        {
                            //ensures the parser is at the start of an rss tag
                            if (eventType == XmlPullParser.START_TAG)
                            {
                                //if the parser is inside the item tag for an earthquake
                                if (xpp.getName().equalsIgnoreCase("item"))
                                {
                                    //sets the boolean variable from earlier to true, to let the parser know we're inside
                                    insideItem = true;
                                    earthquake = new Earthquake();
                                }
                                //parser checks if inside description tag
                                else if (xpp.getName().equalsIgnoreCase("description"))
                                {
                                    //if boolean is true at this stage, parser can start parsing
                                    if (insideItem)
                                    {
                                        //get's description information from the description tag
                                        String description = xpp.nextText();
                                        //takes in the description string and parses it into an array list of the appropriate items.
                                        String[] earthquakeDetails = parseDescription(description);

                                        //Creates a new string comprising of the location and magnitude parsed from the description tag
                                        String locationAndMag = earthquakeDetails[1] + " - " + earthquakeDetails[4];
                                        //adds string of location and magnitude to a string array that will store all earthquakes location and strength to display in the listview
                                        locationAndMagnitude.add(locationAndMag);

                                        //sets the earthquake objects description
                                        earthquake.setDescription(earthquakeDetails);

                                        //Creates a string variable to hold the time parsed from the description tag.
                                        String earthquakeTime = earthquakeDetails[0];
                                        //checks for the label that indicates the actual date and time in the substring
                                            if(earthquakeTime.contains("Origin date/time: "))
                                            {
                                                //addTarget is the target looking to be replaced
                                                String addTarget = "Origin date/time: ";
                                                //addReplacement is what will be inserted in the targets place.
                                                String addReplacement = "";
                                                //replaces the substring of "Origin date/time: " with "", this is the same as deleting it.
                                                earthquakeTime = earthquakeTime.replace(addTarget, addReplacement);
                                            }
                                            //The new value without the "Origin date/time: " text will be assigned to the earthquake objects property
                                        earthquake.setTime(earthquakeTime);

                                        //Creates a string variable to hold the location parsed from the description tag.
                                        String earthquakeLocation = earthquakeDetails[1];
                                        //checks for the label that indicates the actual location in the substring
                                        if(earthquakeLocation.contains(" Location: "))
                                        {
                                            //addTarget is the target looking to be replaced
                                            String addTarget = " Location: ";
                                            //addReplacement is what will be inserted in the targets place.
                                            String addReplacement = "";
                                            //replaces the substring of " Location: " with "", this is the same as deleting it.
                                            earthquakeLocation = earthquakeLocation.replace(addTarget, addReplacement);
                                        }
                                        //The new value without the " Location: " text will be assigned to the earthquake objects property
                                        earthquake.setLocation(earthquakeLocation);

                                        //Difference with replace method here is that it removes a string from the back as well as the front.
                                        //Otherwise the same idea as previous two replaces
                                        String earthquakeDepth = earthquakeDetails[3];
                                        if(earthquakeDepth.contains(" Depth: "))
                                        {
                                            String addTarget = " Depth: ";
                                            String addTarget2 = "km";
                                            String addReplacement = "";
                                            earthquakeDepth = earthquakeDepth.replace(addTarget, addReplacement);
                                            earthquakeDepth = earthquakeDepth.replace(addTarget2, addReplacement);
                                        }
                                        earthquake.setDepth(earthquakeDepth);

                                        //Same as other replaces
                                        String earthquakeMag = earthquakeDetails[4];
                                        if(earthquakeMag.contains(" Magnitude: "))
                                        {
                                            String addTarget = " Magnitude: ";
                                            String addReplacement = "";
                                            earthquakeMag = earthquakeMag.replace(addTarget, addReplacement);
                                        }
                                        earthquake.setMagnitude(earthquakeMag);
                                    }
                                }
                                //if the parser get's to the lat tag
                                else if (xpp.getName().equalsIgnoreCase("geo:lat"))
                                {
                                    //if boolean variable is still true
                                    if (insideItem)
                                    {
                                        //creates string variable to hold the parsed info
                                        String lat = xpp.nextText();
                                        //parses the string to float variable
                                        float floatLat = Float.parseFloat(lat);
                                        //Sets the earthquakes lat using setter
                                        earthquake.setLat(floatLat);
                                    }
                                }
                                //parser gets to longitude tag
                                else if (xpp.getName().equalsIgnoreCase("geo:long"))
                                {
                                    //checks boolean is true
                                    if (insideItem)
                                    {
                                        //creates string to hold parsed info
                                        String lon = xpp.nextText();
                                        //converts string to float
                                        float floatLon = Float.parseFloat(lon);
                                        //uses setter to assign longitude
                                        earthquake.setLon(floatLon);
                                    }
                                }
                            }
                            //if parsers gets to end tag and the end tag is item
                            else if (eventType == XmlPullParser.END_TAG && xpp.getName().equalsIgnoreCase("item"))
                            {
                                //adds the earthquake object to array list of earthquakes
                                earthquakesList.add(earthquake);
                                //sets the boolean variable to false so that when the parser runs through again, it won't parse the wrong info
                                insideItem = false;
                            }
                            //moves the parser to the next object
                            eventType = xpp.next();
                        }

                    }
                    //Exception catches
                    catch (MalformedURLException e)
                    {
                        exception = e;
                    } catch (XmlPullParserException e)
                    {
                        exception = e;
                    } catch (IOException e)
                    {
                        exception = e;
                    }
                }
                //returns exception if any
                return exception;
            }

            //Method runs after main task
            @Override
            protected void onPostExecute(Exception s)
            {
                super.onPostExecute(s);

                //sets the list view to null to ensure no duplication of data
                 lv.setAdapter(null);

                // Create an ArrayAdapter from List
                ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>
                        (MainActivity.this, android.R.layout.simple_list_item_1, locationAndMagnitude)
                {
                    @Override
                    public View getView(int position, View convertView, ViewGroup parent)
                    {
                        // Get the Item from ListView
                        View view = super.getView(position, convertView, parent);

                        // Initialize a TextView for ListView each Item
                        TextView tv = (TextView) view.findViewById(android.R.id.text1);
                        String text = tv.getText().toString();

                        //creates a string variable to hold the magnitude of each item in the list
                        String mag = text.substring(text.lastIndexOf(" ")+1);
                        mag.trim();
                        //converts the string to double to allow for math comparison
                        double magDouble = Double.parseDouble(mag);

                        //if the magnitude of the list item is greater than or equal to 3
                        if(magDouble >= 3)
                        {
                            // Set the text color of the item to red (bad)
                            tv.setBackgroundColor(Color.RED);
                        }
                        //if the magnitude is between 2 and 3
                        else if(magDouble >= 2 && magDouble <3)
                        {
                            // Set the text color of the item to yellow (medium)
                            tv.setBackgroundColor(Color.YELLOW);
                        }
                        //if the magnitude is less than 2
                        else
                        {
                            // Set the text color of the item to green (no problem)
                            tv.setBackgroundColor(Color.GREEN);
                        }
                        //returns the view, allowing list to be displayed
                        return view;
                    }
                };

                //Bind listview with items from adapter
                lv.setAdapter(arrayAdapter);
                //Closes last task down
                progressDialog.dismiss();
            }

            //Method that pulls earthquake information from description RSS tag and converts each item into a string and populates and returns an array string
            public String[] parseDescription(String descriptionIn)
            {
                String[] descriptionDetails = descriptionIn.split(";");
                return descriptionDetails;
            }
        }

    //Toast method
    private void showToast(String message)
    {
        //Allows developer to call toast easier.
        Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
    }
}