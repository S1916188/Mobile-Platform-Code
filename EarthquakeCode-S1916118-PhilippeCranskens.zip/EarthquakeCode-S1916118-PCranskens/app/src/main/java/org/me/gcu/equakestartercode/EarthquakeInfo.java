// Philippe Cranskens - student number - s1916118
package org.me.gcu.equakestartercode;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.UiSettings;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class EarthquakeInfo extends AppCompatActivity implements OnMapReadyCallback {
    //Declaring control variables
    private TextView locationView, timeView, depthView, magView;
    private Button backButton;
    private GoogleMap gMap;
    private Earthquake passedEarthquake;

    @RequiresApi(api = Build.VERSION_CODES.O)
    protected void onCreate(Bundle savedInstanceState)
    {
        requestWindowFeature(Window.FEATURE_NO_TITLE); // hide the title(app name)
        getSupportActionBar().hide(); // Hide the title bar
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN); //enable full screen
        super.onCreate(savedInstanceState);
        setContentView(R.layout.earthquake_details);

        //Finding controls
        locationView = (TextView) findViewById(R.id.txtLocation);
        timeView = (TextView) findViewById(R.id.txtTime);;
        depthView = (TextView) findViewById(R.id.txtDepth);;
        magView = (TextView) findViewById(R.id.txtMag);;
        backButton = (Button) findViewById(R.id.btnBack);

        //Finding the map fragment placed in XML
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.mapsFragment);
        mapFragment.getMapAsync(this);

        //getting the earthquake object passed from main activity
        Earthquake earthquake = (Earthquake) getIntent().getSerializableExtra("earthquake");
        //assigning passed earthquake to global earthquake variable
        passedEarthquake = earthquake;

        //Setting the textviews to information from the earthquake passed over
        locationView.setText("Location: " +earthquake.getLocation());
        timeView.setText("Date and Time: " + earthquake.getTime());
        depthView.setText("Depth: " + earthquake.getDepth() + "km");
        magView.setText("Magnitude: " + earthquake.getMagnitude());

        //Button handler for going back to the main activity
        backButton.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View view)
            {
                //Creates intent for returning to main activity
                Intent myIntent = new Intent(view.getContext(), MainActivity.class);
                startActivityForResult(myIntent,0);
            }
        });
    }

    public void onMapReady(GoogleMap googleMap)
    {
        //creating new instance of google map
        gMap = googleMap;
        //Sets a LatLng variable to the latitude and longitude of the passed earthquake
        LatLng earthquake = new LatLng(passedEarthquake.getLat(), passedEarthquake.getLon());
        if(Double.valueOf(passedEarthquake.getMagnitude()) < 2)
        {
            //adds a new marker to the google map fragment
            gMap.addMarker(new MarkerOptions()
                    .position(earthquake) // The position takes a latlng variable, in this case the one we declared above.
                    .title("Earthquake Location")
                    .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN))); // Adds a title to the pin when selected.
        }
        if(Double.valueOf(passedEarthquake.getMagnitude()) >2 && Double.valueOf(passedEarthquake.getMagnitude()) < 3)
        {
            //adds a new marker to the google map fragment
            gMap.addMarker(new MarkerOptions()
                    .position(earthquake) // The position takes a latlng variable, in this case the one we declared above.
                    .title("Earthquake Location")
                    .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_YELLOW))); // Adds a title to the pin when selected.
        }
        if(Double.valueOf(passedEarthquake.getMagnitude()) > 3)
        {
            //adds a new marker to the google map fragment
            gMap.addMarker(new MarkerOptions()
                    .position(earthquake) // The position takes a latlng variable, in this case the one we declared above.
                    .title("Earthquake Location")
                    .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED))); // Adds a title to the pin when selected.
        }
        //Moves the focus of the map fragment to where the pin is
        gMap.moveCamera(CameraUpdateFactory.newLatLng(earthquake));
        //Set's the zoom level of the map fragment, at this zoom level you can see most of the UK
        gMap.setMinZoomPreference(6);
    }

}
