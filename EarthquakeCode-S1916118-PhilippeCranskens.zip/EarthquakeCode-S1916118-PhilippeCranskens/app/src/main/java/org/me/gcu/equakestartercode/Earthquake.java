// Philippe Cranskens - student number - s1916118
package org.me.gcu.equakestartercode;

import android.os.Build;

import androidx.annotation.RequiresApi;

import java.io.Serializable;
import java.time.ZonedDateTime;

public class Earthquake implements Serializable
{
    private String location;
    private String[] description;
    private String time;
    private String depth;
    private String magnitude;
    private float lat;
    private float lon;

    public String getLocation() {return location;}
    public void setLocation(String location) {this.location = location;}

    public String[] getDescription() {return description;}
    public void setDescription(String[] description) {this.description = description;}

    public String getTime() {return time;}
    public void setTime(String time) {this.time = time;}

    public String getMagnitude() {return magnitude;}
    public void setMagnitude(String magnitude) {this.magnitude = magnitude;}

    public String getDepth() {return depth;}
    public void setDepth(String depth) {this.depth = depth;}

    public float getLat() {return lat;}
    public void setLat(float lat) {this.lat = lat;}

    public float getLon() {return lon;}
    public void setLon(float lon) {this.lon = lon;}


    @RequiresApi(api = Build.VERSION_CODES.O)
    public Earthquake()
    {
        location = "";
        description = null;
        time = "";
        depth = "";
        magnitude = "";
        lat = 0;
        lon = 0;
    }

    public Earthquake(String locationIn, String[] descriptionIn,String timeIn,
                      String depthIn, String magnitudeIn, float latIn, float longIn)
    {
        location = locationIn;
        description = descriptionIn;
        time = timeIn;
        depth = depthIn;
        magnitude = magnitudeIn;
        lat = latIn;
        lon = longIn;
    }


    public String toString()
    {
        String earthquakeString = location + " " + description + " " + time + " " +
                depth + " " + magnitude + " " + lat + " " + lon;

        return earthquakeString;
    }

} // End of class
