// Philippe Cranskens - student number - s1916118
package org.me.gcu.equakestartercode;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.ArrayList;

public class SearchInfo extends AppCompatActivity implements OnMapReadyCallback
{
    private ArrayList<Earthquake> earthquakesSearch;
    private GoogleMap gMap;
    private Earthquake furthestNorth, furthestSouth, furthestEast, furthestWest, shallowest, deepest, largestMag;
    private TextView txtNorth, txtSouth, txtEast, txtWest, txtDeep, txtShallow, txtMag;
    private Button back;


    @RequiresApi(api = Build.VERSION_CODES.O)
    protected void onCreate(Bundle savedInstanceState)
    {
        requestWindowFeature(Window.FEATURE_NO_TITLE); // hide the title(app name)
        getSupportActionBar().hide(); // Hide the title bar
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN); //enable full screen
        super.onCreate(savedInstanceState);
        setContentView(R.layout.search_info);

        //Finding the map fragment placed in XML
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.mapsFragment);
        mapFragment.getMapAsync(this);

        earthquakesSearch = new ArrayList<Earthquake>();
        earthquakesSearch = (ArrayList<Earthquake>) getIntent().getSerializableExtra("earthquakeList");

        //method to find controls as there is a lot and this declutters onCreate
        findControls();
        //Method that sorts the earthquakes based on the parameters outlined in the coursework and then displays them using the controls in the xml
        sortEarthquakes();

        //Button handles navigation back to the main activity page
        back.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View view)
            {
                Intent myIntent = new Intent(view.getContext(), MainActivity.class);
                startActivityForResult(myIntent,0);
            }
        });
    }

    //Finds all controls in the xml
    private void findControls()
    {
        txtNorth = (TextView) findViewById(R.id.txtNorthern);
        txtSouth = (TextView) findViewById(R.id.txtSouthern);
        txtEast = (TextView) findViewById(R.id.txtEastern);
        txtWest = (TextView) findViewById(R.id.txtWestern);
        txtDeep = (TextView) findViewById(R.id.txtDeepest);
        txtShallow = (TextView) findViewById(R.id.txtShallowest);
        txtMag = (TextView) findViewById(R.id.txtMagnitude);
        back = (Button) findViewById(R.id.btnBackToMain);
    }

    //sorts the earthquakes passed over and assigns them to xml controls
    @RequiresApi(api = Build.VERSION_CODES.O)
    private void sortEarthquakes()
    {
        //Each earthquake is declared as a global variable at the top of the file
        //each instance then is assigned the first earthquake in the list of earthquakes passed over
        furthestNorth = earthquakesSearch.get(0);
        furthestSouth = earthquakesSearch.get(0);
        furthestEast = earthquakesSearch.get(0);
        furthestWest = earthquakesSearch.get(0);
        shallowest = earthquakesSearch.get(0);
        deepest = earthquakesSearch.get(0);
        largestMag = earthquakesSearch.get(0);

        try
        {
            //loop through list of earthquakes in date range
            for (int i = 0; i < earthquakesSearch.size(); i++)
            {
                //Get current earthquake in list
                Earthquake currentEarthquake = earthquakesSearch.get(i);
                //compare earthquakes with furthest north recorded so far
                if (currentEarthquake.getLat() > furthestNorth.getLat())
                {
                    //if the current earthquake is further north than the furthestNorth so far, it then becomes the newest furthestNorth
                    furthestNorth = currentEarthquake;
                }
                //compare earthquakes with furthest south recorded so far
                if (currentEarthquake.getLat() < furthestSouth.getLat())
                {
                    //if the current earthquake is further south than the furthestSouth so far, it then becomes the newest furthestSouth
                    furthestSouth = currentEarthquake;
                }
                //compare earthquakes with furthest east recorded so far
                if (currentEarthquake.getLon() > furthestEast.getLon())
                {
                    //if the current earthquake is further east than the furthestEast so far, it then becomes the newest furthestEast
                    furthestEast = currentEarthquake;
                }
                //compare earthquakes with furthest west recorded so far
                if (currentEarthquake.getLon() < furthestWest.getLon())
                {
                    //if the current earthquake is further west than the furthestWest so far, it then becomes the newest furthestWest
                    furthestWest = currentEarthquake;
                }

                //get double value of current shallowest earthquake depth
                String shallowStringCurrent = currentEarthquake.getDepth();
                double shallowDoubleCurrent = Double.parseDouble(shallowStringCurrent);

                //get double value of shallowest earthquake depth
                String shallowStringPrevious = shallowest.getDepth();
                double shallowDoublePrevious = Double.parseDouble(shallowStringPrevious);

                //compares the current shallowest with the current earthquake
                if (shallowDoubleCurrent < shallowDoublePrevious)
                {
                    //if the current earthquake is shallower than the shallowest so far, it then becomes the newest shallowest
                    shallowest = currentEarthquake;
                }

                //get double value of current shallowest earthquake depth
                String deepestStringCurrent = currentEarthquake.getDepth();
                double deepestDoubleCurrent = Double.parseDouble(deepestStringCurrent);

                //get double value of deepest earthquake depth
                String depthStringPrevious = deepest.getDepth();
                double depthDoublePrevious = Double.parseDouble(depthStringPrevious);

                //compares the current deepest with the current earthquake
                if (deepestDoubleCurrent > depthDoublePrevious)
                {
                    //if the current earthquake is deeper than the deepest so far, it then becomes the newest deepest
                    deepest = currentEarthquake;
                }

                //get double value of current earthquake magnitude
                String magStringCurrent = currentEarthquake.getMagnitude();
                double magDoubleCurrent = Double.parseDouble(magStringCurrent);

                //get double value of largest magnitude earthquake
                String magStringPrevious = largestMag.getMagnitude();
                double magDoublePrevious = Double.parseDouble(magStringPrevious);

                //compares the current largest magnitude with the current earthquake
                if (magDoubleCurrent > magDoublePrevious)
                {
                    //if the current earthquake is a larger magnitude than the largest so far, it then becomes the newest largest
                    largestMag = currentEarthquake;
                }
            } // end of loop

            //Sets the textviews for each statistic to the values defined after working out the highest or lowest values
            txtNorth.setText("Furthest North: " + furthestNorth.getLocation());
            txtSouth.setText("Furthest South: " + furthestSouth.getLocation());
            txtEast.setText("Furthest East: " + furthestEast.getLocation());
            txtWest.setText("Furthest West: " + furthestWest.getLocation());
            txtDeep.setText("Deepest: " + deepest.getLocation() + " " + deepest.getDepth() +"km");
            txtShallow.setText("Shallowest: " + shallowest.getLocation() + " " + shallowest.getDepth() +"km");
            txtMag.setText("Largest Magnitude: " + largestMag.getLocation() + " Magnitude: " + largestMag.getMagnitude());
        }
        //catches any exceptions
        catch (Exception ex)
        {
            //Logs exception for viewing
            Log.d("EXCEPTION", ex.toString());
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onMapReady(GoogleMap googleMap)
    {
        //creates new instance of google map
        gMap = googleMap;
        //clears map
        gMap.clear();

        //Add pin for furthest North
       LatLng mostNorth = new LatLng(furthestNorth.getLat(), furthestNorth.getLon());
        gMap.addMarker(new MarkerOptions()
                .position(mostNorth)
                .title("Furthest North"));

        //Add pin for furthest North
        LatLng mostSouth = new LatLng(furthestSouth.getLat(), furthestSouth.getLon());
        gMap.addMarker(new MarkerOptions()
                .position(mostSouth)
                .title("Furthest South"));

        //Add pin for furthest North
        LatLng mostEast = new LatLng(furthestEast.getLat(), furthestEast.getLon());
        gMap.addMarker(new MarkerOptions()
                .position(mostEast)
                .title("Furthest East"));

        //Add pin for furthest North
        LatLng mostWest = new LatLng(furthestWest.getLat(), furthestWest.getLon());
        gMap.addMarker(new MarkerOptions()
                .position(mostWest)
                .title("Furthest West"));

        //Add pin for furthest North
        LatLng shallowestMarker = new LatLng(shallowest.getLat(), shallowest.getLon());
        gMap.addMarker(new MarkerOptions()
                .position(shallowestMarker)
                .title("Shallowest Earthquake"));

        //Add pin for furthest North
        LatLng DeepestMarker = new LatLng(deepest.getLat(), deepest.getLon());
        gMap.addMarker(new MarkerOptions()
                .position(DeepestMarker)
                .title("Deepest Earthquake"));

        //Add pin for furthest North
        LatLng largestMagMarker = new LatLng(largestMag.getLat(), largestMag.getLon());
        gMap.addMarker(new MarkerOptions()
                .position(largestMagMarker)
                .title("Largest Magnitude"));

        LatLng centeredCamera = new LatLng(54.518457831715104, -3.0047520676891346); // Coordinates for the middle of the UK roughly, as a center point for the camera to focus
        gMap.moveCamera(CameraUpdateFactory.newLatLng(centeredCamera)); // moves the camera to the coordinates specified above
        gMap.setMinZoomPreference(4); // sets the zoom level quite low so the user can see the full country
    }
}
